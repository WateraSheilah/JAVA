/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/TagHandler.java to edit this template
 */
package custom;

import jakarta.servlet.jsp.JspWriter;
import jakarta.servlet.jsp.JspException;
import jakarta.servlet.jsp.tagext.JspFragment;
import jakarta.servlet.jsp.tagext.SimpleTagSupport;

public class product extends SimpleTagSupport {

    private int longterm;
    private int shortterm;
    private int midterm;


    @Override
    public void doTag() throws JspException {
        JspWriter out = getJspContext().getOut();
        
        try {
            out.println("the long term, short term and mid term are "+this.longterm+" "+this.longterm*2+" "+this.midterm*5);
           

           
        } catch (java.io.IOException ex) {
            throw new JspException("Error in product tag", ex);
        }
    }

    public void setLongterm(int longterm) {
        this.longterm = longterm;
    }

    public void setShortterm(int shortterm) {
        this.shortterm = shortterm;
    }

    public void setMidterm(int midterm) {
        this.midterm = midterm;
    }
    
}
