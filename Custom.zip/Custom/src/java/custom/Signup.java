/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package custom;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


@WebServlet(name = "Signup", urlPatterns = {"/Signup"})
public class Signup extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
               try(
        PrintWriter out = response.getWriter()){
        
        String username=request.getParameter("username");
        String password =request.getParameter("pass");
        String userage =request.getParameter("userage");
        String email =request.getParameter("email");
        

   try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/code_avengers","root","");
        Statement st = con.createStatement();
        
        
        ResultSet usercheck = st.executeQuery("select * from user where username='"+username+"'");
        if(usercheck.next()){
            out.println("<script type=\"text/javascript\">");
            out.println("window.alert('sorry, this username is already taken');");
            out.println("location='Signup.jsp';");
            out.println("</script>");
            }
        
            else{
             st.executeUpdate("insert into user (username,password,email,user age) values('" + username + "','" + password + "','" + email + "','" + userage + "')");
            out.println("<script type=\"text/javascript\">");
            out.println("window.alert('you have been registered successfully!');");
            out.println("location='Signin.jsp';");
            out.println("</script>");
            
            }
        

   
   
            } catch(Exception e){
            
              out.println(e);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
