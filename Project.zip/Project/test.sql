-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2022 at 08:45 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` varchar(100) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `phoneNumber` bigint(20) DEFAULT NULL,
  `orderDate` varchar(100) DEFAULT NULL,
  `deliveryDate` varchar(100) DEFAULT NULL,
  `paymentMethod` varchar(100) DEFAULT NULL,
  `transactionId` varchar(100) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`email`, `product_id`, `quantity`, `price`, `total`, `address`, `city`, `state`, `country`, `phoneNumber`, `orderDate`, `deliveryDate`, `paymentMethod`, `transactionId`, `status`) VALUES
('markelsa01@gmail.com', 2, 4, 1234, 4936, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('markelsa01@gmail.com', 1, 2, 90555, 181110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('markelsa01@gmail.com', 3, 3, 12345, 37035, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('ssemakulapeterwasswa20@gmail.com', 4, 2, 90909000, 181818000, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:20:14', '2022-08-17 15:20:14.000000', ' Cash on delivery(COD)', '', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 4, 1234, 4936, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:20:14', '2022-08-17 15:20:14.000000', ' Cash on delivery(COD)', '', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 4, 90555, 362220, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:20:14', '2022-08-17 15:20:14.000000', ' Cash on delivery(COD)', '', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 3, 1, 12345, 12345, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:20:14', '2022-08-17 15:20:14.000000', ' Cash on delivery(COD)', '', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 4, 2, 90909000, 181818000, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:36:32', '2022-08-17 15:36:32.000000', 'Online Payment', '1234', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 1, 90555, 90555, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:36:32', '2022-08-17 15:36:32.000000', 'Online Payment', '1234', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 1, 1234, 1234, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:36:32', '2022-08-17 15:36:32.000000', 'Online Payment', '1234', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 3, 1, 12345, 12345, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:36:32', '2022-08-17 15:36:32.000000', 'Online Payment', '1234', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 2, 90555, 181110, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:49:45', '2022-08-17 15:49:45.000000', 'Online Payment', '55555', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 2, 1234, 2468, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:49:45', '2022-08-17 15:49:45.000000', 'Online Payment', '55555', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 3, 2, 12345, 24690, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:49:45', '2022-08-17 15:49:45.000000', 'Online Payment', '55555', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 4, 1, 90909000, 90909000, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:49:45', '2022-08-17 15:49:45.000000', 'Online Payment', '55555', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 1, 90555, 90555, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:54:37', '2022-08-17 15:54:37.000000', ' Cash on delivery(COD)', '22222', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 1, 1234, 1234, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 15:54:37', '2022-08-17 15:54:37.000000', ' Cash on delivery(COD)', '22222', 'processing'),
('boss@gmail.com', 1, 1, 90555, 90555, 'Germany', 'Germany', 'Germany', 'Germany', 708392544, '2022-08-10 16:19:54', '2022-08-17 16:19:54.000000', 'Online Payment', '56', 'processing'),
('boss@gmail.com', 2, 1, 1234, 1234, 'Germany', 'Germany', 'Germany', 'Germany', 708392544, '2022-08-10 16:19:54', '2022-08-17 16:19:54.000000', 'Online Payment', '56', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 1, 90555, 90555, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 17:03:02', '2022-08-17 17:03:02.000000', 'Online Payment', '1111222', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 1, 1234, 1234, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 17:03:02', '2022-08-17 17:03:02.000000', 'Online Payment', '1111222', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 3, 1, 12345, 12345, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 17:03:02', '2022-08-17 17:03:02.000000', 'Online Payment', '1111222', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 4, 1, 90909000, 90909000, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 17:03:02', '2022-08-17 17:03:02.000000', 'Online Payment', '1111222', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 1, 90555, 90555, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 18:08:43', '2022-08-17 18:08:43.000000', 'Online Payment', '134', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 2, 1, 1234, 1234, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 18:08:43', '2022-08-17 18:08:43.000000', 'Online Payment', '134', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 3, 3, 12345, 37035, 'Los Angeles', 'united States', 'LA', 'US', 4444444, '2022-08-10 18:08:43', '2022-08-17 18:08:43.000000', 'Online Payment', '134', 'processing'),
('ssemakulapeterwasswa20@gmail.com', 1, 11, 90555, 996105, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
('andersonixon12@gmail.com', 4, 1, 90909000, 90909000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catId` int(4) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catId`, `category`) VALUES
(1, 'Furniture'),
(2, 'Bakery'),
(3, 'Clothings'),
(4, 'Stationery');

-- --------------------------------------------------------

--
-- Table structure for table `dailysales`
--

CREATE TABLE `dailysales` (
  `productname` varchar(20) NOT NULL,
  `totalSales` int(15) NOT NULL,
  `date` date NOT NULL,
  `catId` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailysales`
--

INSERT INTO `dailysales` (`productname`, `totalSales`, `date`, `catId`) VALUES
('Beds', 45000, '2022-08-11', 1),
('Pens', 56000, '2022-08-18', 4),
('Beds', 45000, '2022-08-11', 1),
('Pens', 56000, '2022-08-18', 4);

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE `manager` (
  `id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`id`, `name`, `password`, `email`, `username`) VALUES
(5, 'RACHKARA ANGEL', 'watesha3535', 'waterasheilah@gmail.com', 'watesha'),
(6, 'RACHKARA ANGEL', '1234', 'waterasheilah@gmail.com', 'angel'),
(7, 'Akahirwa Daniel', 'aka1234', 'akahirwadanile@gmail.com', 'Pro'),
(8, 'RACHKARA ANGEL', 'haira3535', 'waterasheilah@gmail.com', 'haira'),
(9, 'RACHKARA ANGEL', 'pro3535', 'banaddamubaraka68@gmail.com', 'pro3535'),
(10, 'watera', 'marvin3535', 'ricky@gmail.com', 'marvin'),
(11, 'test', 'test', 'test@test.com', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `body` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `email`, `subject`, `body`) VALUES
(1, 'markelsa01@gmail.com', '2fddfgfvc', 'Zxcvbnm,klm,mhngbvfasdfghjkhgfdscxzvb'),
(2, 'markelsa01@gmail.com', 'wertyuikjhngbfvderrtyujh', 'rtfgcvxccfgvhbjkjmhngbfvccxvbnm'),
(3, 'ssemakulapeterwasswa20@gmail.com', 'hello boss', 'i  really like ur site'),
(4, 'ssemakulapeterwasswa20@gmail.com', 'hey', 'i am checking this site');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productId` int(4) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `catId` int(4) NOT NULL,
  `price` int(50) NOT NULL,
  `productline` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productId`, `productname`, `catId`, `price`, `productline`) VALUES
(1, 'Beds', 1, 50000, 'long-term'),
(2, 'Tables', 1, 40000, 'short-term'),
(3, 'Chairs', 1, 45000, 'mid-term'),
(4, 'Cakes', 2, 10000, 'long-term'),
(5, 'Bread', 2, 5000, 'mid-term'),
(6, 'Cookies', 2, 1000, 'short-term'),
(7, 'Jackets', 3, 65000, 'mid-term'),
(8, 'T-Shirts', 3, 35000, 'short-term'),
(9, 'Suits', 3, 100000, 'long-term'),
(10, 'Books', 4, 4000, 'long-term'),
(11, 'Pens', 4, 1500, 'mid-term'),
(12, 'Pencils', 4, 1000, 'short-term');

-- --------------------------------------------------------

--
-- Table structure for table `productsales`
--

CREATE TABLE `productsales` (
  `category` varchar(50) NOT NULL,
  `catId` int(11) NOT NULL,
  `categorysales` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staffdetails`
--

CREATE TABLE `staffdetails` (
  `sid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `catId` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffdetails`
--

INSERT INTO `staffdetails` (`sid`, `fname`, `lname`, `email`, `gender`, `catId`) VALUES
(1, 'Watera', 'Sheilah', 'waterasheilah@gmail.com', 'F', 1),
(2, 'Namulidwe', 'Madrine', 'namulidwemadrine@gmail.com', 'F', 4),
(3, 'Asiiswe', 'Tinah', 'christine@gmail.com', 'F', 3),
(4, 'Juuko', 'Roman', 'juuko@gmail.com', 'M', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `phoneNumber` bigint(20) DEFAULT NULL,
  `securityQuestion` varchar(200) DEFAULT NULL,
  `answer` varchar(200) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `email`, `phoneNumber`, `securityQuestion`, `answer`, `password`, `address`, `city`, `state`, `country`) VALUES
('Anderson', 'andersonixon12@gmail.com', 24456278899, 'What is the name of the town where you were born?', 'kampala', 'anderson', '', '', '', ''),
('boss', 'boss@gmail.com', 708392544, 'What is the name of the town where you were born?', 'Vancouver', '1234', 'Germany', 'Germany', 'Germany', 'Germany'),
('Tonny', 'markelsa01@gmail.com', 1234, 'What was your first car?', 'minbvs', '12345678', 'Makerere', 'Kampala', 'Kampala', 'Uganda'),
('Mutebi Tonny', 'Mutebi Tonny', NULL, 'What was your first car?<', 'subaru', '1234567890', '', '', '', ''),
('Mutebi Tonny', 'mutebitonny75@gmail.com', 3456789, 'What was your first car?', 'subaru', '234567890-', '', '', '', ''),
('Madrine', 'namulindwa20@gmail.com', 708292544, 'What was your first car?', 'vitz', '1234', '', '', '', ''),
('Mutebi Tonny', 'ssemakulapeterwasswa20@gmail.com', 4444444, 'What was your first car?', 'many', '1234', 'Los Angeles', 'united States', 'LA', 'US');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `dailysales`
--
ALTER TABLE `dailysales`
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `manager`
--
ALTER TABLE `manager`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `productsales`
--
ALTER TABLE `productsales`
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `staffdetails`
--
ALTER TABLE `staffdetails`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `catId` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `manager`
--
ALTER TABLE `manager`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staffdetails`
--
ALTER TABLE `staffdetails`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dailysales`
--
ALTER TABLE `dailysales`
  ADD CONSTRAINT `dailysales_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);

--
-- Constraints for table `staffdetails`
--
ALTER TABLE `staffdetails`
  ADD CONSTRAINT `staffdetails_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
