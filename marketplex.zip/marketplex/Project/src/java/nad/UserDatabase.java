/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package nad;

import java.sql.*;

/**
 *
 * @author DSN
 */
public class UserDatabase {
    Connection con;
    public UserDatabase(Connection con){
        this.con=con;
    }
    //for registration
    public boolean saveUser(User user){
        boolean set=false;
        try{
                        //insert register data to database
            String query="insert into user(name,password,email,username) values(?,?,?,?)";
            
            PreparedStatement pt=this.con.prepareStatement(query);
            pt.setString(1, user.getName());
            pt.setString(2, user.getPassword());
            pt.setString(3, user.getEmail());
            pt.setString(4, user.getUsername());
            
            
            pt.executeUpdate();
            set=true;
        }catch(Exception e){
            e.printStackTrace();
        }
        return set;
    }
    }
    
    

