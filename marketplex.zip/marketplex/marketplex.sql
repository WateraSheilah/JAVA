-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2022 at 03:51 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `catId` int(4) NOT NULL,
  `category` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`catId`, `category`) VALUES
(1, 'Furniture'),
(2, 'Bakery'),
(3, 'Clothings'),
(4, 'Stationery');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `location` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(24) NOT NULL,
  `customerid` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`fname`, `lname`, `location`, `email`, `gender`, `username`, `password`, `customerid`) VALUES
('watera', 'sheilah', 'namugongo', 'waterasheilah@gmail.com', 'F', 'watesha', 'watesha3535', 1),
('Nagawa', 'Hairatu', 'Kitawlute', 'hairatoto@gmail.com', 'F', 'Hairatu', 'haira3535', 2),
('Namulidwe', 'Madrine', 'Kisugu', 'namulidwemadrine@gmail.com', 'F', 'madrine', 'madrine3535', 3);

-- --------------------------------------------------------

--
-- Table structure for table `dailysales`
--

CREATE TABLE `dailysales` (
  `productname` varchar(20) NOT NULL,
  `totalSales` int(15) NOT NULL,
  `date` date NOT NULL,
  `catId` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dailysales`
--

INSERT INTO `dailysales` (`productname`, `totalSales`, `date`, `catId`) VALUES
('Beds', 45000, '2022-08-11', 1),
('Pens', 56000, '2022-08-18', 4),
('Beds', 45000, '2022-08-11', 1),
('Pens', 56000, '2022-08-18', 4);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productId` int(4) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `catId` int(4) NOT NULL,
  `price` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productId`, `productname`, `catId`, `price`) VALUES
(1, 'Beds', 1, 0),
(2, 'Tables', 1, 0),
(3, 'Chairs', 1, 0),
(4, 'Cakes', 2, 0),
(5, 'Bread', 2, 0),
(6, 'Cookies', 2, 0),
(7, 'Jackets', 3, 0),
(8, 'T-Shirts', 3, 0),
(9, 'Suits', 3, 0),
(10, 'Books', 4, 0),
(11, 'Pens', 4, 0),
(12, 'Pencils', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `productsales`
--

CREATE TABLE `productsales` (
  `category` varchar(50) NOT NULL,
  `catId` int(11) NOT NULL,
  `categorysales` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staffdetails`
--

CREATE TABLE `staffdetails` (
  `sid` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `catId` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffdetails`
--

INSERT INTO `staffdetails` (`sid`, `fname`, `lname`, `email`, `gender`, `catId`) VALUES
(1, 'Watera', 'Sheilah', 'waterasheilah@gmail.com', 'F', 1),
(2, 'Namulidwe', 'Madrine', 'namulidwemadrine@gmail.com', 'F', 4),
(3, 'Asiiswe', 'Tinah', 'christine@gmail.com', 'F', 3),
(4, 'Juuko', 'Roman', 'juuko@gmail.com', 'M', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `password`, `email`, `username`) VALUES
(5, 'RACHKARA ANGEL', 'watesha3535', 'waterasheilah@gmail.com', 'watesha'),
(6, 'RACHKARA ANGEL', '1234', 'waterasheilah@gmail.com', 'angel'),
(7, 'Akahirwa Daniel', 'aka1234', 'akahirwadanile@gmail.com', 'Pro'),
(8, 'RACHKARA ANGEL', 'haira3535', 'waterasheilah@gmail.com', 'haira'),
(9, 'RACHKARA ANGEL', 'pro3535', 'banaddamubaraka68@gmail.com', 'pro3535'),
(10, 'watera', 'marvin3535', 'ricky@gmail.com', 'marvin'),
(11, 'test', 'test', 'test@test.com', 'test');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`catId`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customerid`);

--
-- Indexes for table `dailysales`
--
ALTER TABLE `dailysales`
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productId`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `productsales`
--
ALTER TABLE `productsales`
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `staffdetails`
--
ALTER TABLE `staffdetails`
  ADD PRIMARY KEY (`sid`),
  ADD KEY `catId` (`catId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `catId` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customerid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staffdetails`
--
ALTER TABLE `staffdetails`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dailysales`
--
ALTER TABLE `dailysales`
  ADD CONSTRAINT `dailysales_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);

--
-- Constraints for table `staffdetails`
--
ALTER TABLE `staffdetails`
  ADD CONSTRAINT `staffdetails_ibfk_1` FOREIGN KEY (`catId`) REFERENCES `category` (`catId`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
