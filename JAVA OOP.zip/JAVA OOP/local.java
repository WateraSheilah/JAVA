import java.util.Scanner;

import java.util.*;
public class local extends Quest{
    static int discount;
    public static void main(String[]args){
        local l=new local();
        Scanner s=new Scanner(System.in);
        System.out.println("Enter your name");
        l.name=s.nextLine();
        System.out.println("Enter your contact");
        l.contact=s.nextInt();
        System.out.println("Enter your consumed");
        l.consumed=s.nextInt();
        System.out.println("Enter your charge");
        l.charge=s.nextInt();
        
        int total;
        discount=3;
        total=(l.charge*l.consumed)+tax-discount;
        l.printDetails();
        System.out.println("The total is "+total);
        }
}
