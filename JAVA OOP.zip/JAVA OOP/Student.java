import java.io.*;
import java.net.*;
public class Student {
    public static String Program;
    public String Regno;

    public void printRegno(){
        System.out.println("Regno"+ this.Regno);
    }
    public static void setProgram(String s){
        Student.Program=s;
    }
    public static void main(String[]args){
        Student obj= new Student();
        obj.Regno="20/U/7754/PS";
        Student.setProgram("BSSE");
        System.out.println(Student.Program);
        
    }
}