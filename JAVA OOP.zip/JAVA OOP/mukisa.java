import java.io.*;
import java.util.*;
import java.net.*;
import java.lang.*;
public class mukisa {
    public String Name;
    public Double Quantity;
    public Double Price;
    public Double Income;
    public final static int Tax= 350; 
    //public Double Sales;


    public void printDetails(){
        System.out.println("Name: "+this.Name);
        System.out.println("Quantity: "+this.Quantity);
        System.out.println("Price: "+this.Price);
        System.out.println("Income: "+this.Income);
        //System.out.println("Sales:"+this.Sales);

    }
    
public static void main(String[]args){
mukisa m=new mukisa();
Scanner s =new Scanner(System.in);
System.out.println("Enter the Name of the product");
m.Name=s.nextLine();
System.out.println("Enter the Quantity of the product");
m.Quantity=s.nextDouble();
System.out.println("Enter the Price of the product");
m.Price=s.nextDouble();
m.Income=m.Quantity*m.Price - Tax;
System.out.println("The Income of the product is "+m.Income);
m.printDetails();
s.close();





}}
 