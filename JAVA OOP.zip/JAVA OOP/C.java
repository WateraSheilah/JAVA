import java.io.*;
public class C implements A,B{
    public void printone(){
        System.out.println("This is one");
    }
    public static void main(String[] args){
        C c =new C();
        c.printone();
    }
}
