import java.io.*;
public class multiArray {
    public static void main(String[]args){
        int r=2;
        int c=4;

        int[][] MatrixA = { {1, 1, 1, 1}, {2, 3, 5, 2} };
        int[][] MatrixB = { {2, 3, 4, 5}, {2, 2, 4, -4} };

        int[][] sum= new int[r][c];
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                sum[i][j]= MatrixA[i][j]+ MatrixB[i][j];
            }
        }
        for(int i=0;i<r;i++){
            for(int j=0;j<c;j++){
                System.out.println("the sum is "+sum[i][j]);
            }
        }
        System.out.println();
    }
}
