public class People {
    public int Age;
    public String Name;
    public void printDetails(){
        System.out.println("Name"+this.Name);
        System.out.println("Name"+this.Age);
    }
}
