
import java.io.*;
import java.net.*;
import java.util.*;
public class Land {
    int length;
    int width;
    static int total;
    final static int pad=100;
    int Total_area;
    public void area(){
     total=length*width;
     System.out.println("the total area is "+total+"cm");
     
    }
    public static void main(String[]args){
        Land l = new Land();
        Scanner s =new Scanner(System.in);
        System.out.println("Enter the length");
        l.length= s.nextInt();
        System.out.println("Enter the width");
        l.width= s.nextInt();
        l.area();
   l.Total_area=pad*total;
   System.out.println("Enter the Total Area is "+l.Total_area+"cm");
        
    }
}
