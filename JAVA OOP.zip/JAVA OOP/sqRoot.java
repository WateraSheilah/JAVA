import java.io.*;
import java.util.*;
public class sqRoot {
    int element;
    public static void main(String[]args){
        int element;
        sqRoot r= new sqRoot();
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the num whose square root is needed: ");
       r.element=s.nextInt();
       double x= Math.pow(r.element, 2);
       System.out.print("The square root of "+r.element +" is "+x);


    }
    
}
