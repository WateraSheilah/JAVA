import java.util.Scanner;

public class Pupil extends People {
    public String RegNo;
    public void printDetails(){
        super.printDetails();
        System.out.println("RegNo:"+RegNo);
    }
    public static void main(String[]args){
        Scanner s=new Scanner(System.in);
        Pupil obj=new Pupil();
        System.out.println("Enter Age");
        obj.Age=s.nextInt();
        System.out.println("Enter Name");
        obj.Name=s.nextLine();
        System.out.println("Enter RegNo.");
        obj.RegNo=s.nextLine();
       
        obj.printDetails();

    }
    
}
