interface B {
    public void printone();
}
