import java.util.*;
public class Input {
    
    public static void main(String[]args){
        int sum=0;
        double ave= 0;
        Scanner s = new Scanner(System.in);
        
        System.out.println("enter the number of elements you want");
        int n=s.nextInt();
        int[] array1= new int[n];

        System.out.println("enter the elements you want");

        for(int i=0;i<n;i++){
          array1[i]=s.nextInt();
        }
        System.out.println("enter the elements are; ");
        for(int i=0;i<n;i++){
            System.out.println(array1[i]);
        }
        for(int i=0;i<array1.length;i++){
            //int sum=0;
            sum= sum + array1[i];
            ave = sum/array1.length;
        
        }
        System.out.println("The sum is "+sum);
        System.out.println("The average is "+ave);
    }
    
}
