import java.io.*;
import java.util.*;
import java.net.*;
import java.time.LocalDate;
public class MTN {
    public String Agentno;
    public String Name;
    public int YOB = 2000;
    public int CalculateAge(){
        int y= 2022;
        int age=y-YOB;
      
        return age;
    }
    public static void main(String[]args){
        MTN m= new MTN();
       System.out.println(m.CalculateAge());
    
    
}
}
