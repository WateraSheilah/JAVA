interface A {
    public void printone();

}

