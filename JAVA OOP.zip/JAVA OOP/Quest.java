public class Quest {
    static final int tax=5;
    String name;
    int contact;
    int consumed;
    int charge;
    public void printDetails(){
        System.out.println(" your name " +this.name);
        System.out.println(" your name "+this.contact);
        System.out.println(" your name "+this.charge);
        System.out.println(" your name "+this.consumed);
        
    }
}
