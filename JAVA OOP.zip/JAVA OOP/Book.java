import java.io.*;
import java.net.*;
public class Book{
    public String Title;
    public String Price;
    public Book(String t, String p){
        Title=t;
        Price=p;
    }
    public static void main(String[] args){
       Book bk= new Book("Mindset", "7.5");
       System.out.println("Title: "+bk.Title);
       System.out.println("Price: "+bk.Price);

    }
    }