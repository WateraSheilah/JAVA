
import java.util.*;
public class Triangle{
    public static int length;
    public static int width;
    public static int height;
    
    public static void main(String[]args){
        Triangle t=new Triangle();
        Scanner s =new Scanner(System.in);
        System.out.print("Enter the Length: ");
        t.length=s.nextInt();
        System.out.print("Enter the Width: ");
        t.width=s.nextInt();
        System.out.print("Enter the Height: ");
        t.height=s.nextInt();
        if(length == width && width == height &&height == length){
            System.out.print("This is an Equilateral Triangle");

        }
        else if(length==width||width==height||height==length){
            System.out.print("This is an Isosceles Triangle");
        }
        else if(length!=width&&width!=height&&height!=length){
            System.out.print("This is a Scalene Triangle");
            
        }
        else if(length*length==width*width+height*height){
            System.out.print("This is a Right Angled Triangle");

        }
        s.close();

    }
}

