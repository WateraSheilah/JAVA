//import java.util.Collections;
import java.util.*;
//import java.io.*;
//import java.net.*;
public class Array1 {
    public static void main(String[] args){
            int[] num1 = {
                3,2,6,8,4,9,1
            };
            System.out.println("the orignal array is: "+Arrays.toString(num1));
            Arrays.sort(num1);
            System.out.println("the sorted array is: "+Arrays.toString(num1));

        
    }
    
}
