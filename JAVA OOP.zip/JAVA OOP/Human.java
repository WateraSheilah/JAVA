public class Human {
    public String name;
    public int age;
    public Human(){
        name = "watera";
        //age=a;

    }
    public static void main(String[]args){
    Human h =new Human();
    System.out.println("Name: "+h.name);
   // System.out.println("ID: "+h.id); 
    System.out.println("Age: "+h.age);
    

    }
    
    
}
