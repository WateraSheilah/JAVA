import java.io.*;
import java.net.*;
import java.util.*;

public class Employee {
    String employeeNo;
    int Salary;
    public static void main(String[] args){
        int i;
        int n=3;
        Employee[] e =new Employee[n];
        Scanner s = new Scanner(System.in);
        
        //inputing the needed data
        for(i=0;i<n;i++){
            e[i]=new Employee();
            System.out.println("Enter yor EmployeeNumber: ");
            e[i].employeeNo=s.next();
            System.out.println("Enter yor Salary: ");
            e[i].Salary=s.nextInt();
        //checking if the salary entered is negative
            if(e[i].Salary<0){
                System.out.println("Enter the valid Salary ");
               break;
            }}
            //printing the entered details
            for(i=0;i<n;i++){
                System.out.print("EmployeeNumber: ");
                System.out.println(e[i].employeeNo);
                System.out.print("Salary: ");
                System.out.println(e[i].Salary);

            }
        }
    }
    

