
import java.io.*;
import java.net.*;
import java.util.*;
public class Business{
    public int rent;
    public final int tax=1000;
    public int price;

public class Timber extends Business { 
    public int no;
    public void income =(price*no)-tax;
   
    
}
public class Salon extends Business {
    public int num;
    public int income =(price*num)-tax;
    
}}
