// send datagram packet to server from command line
import java.io.*;
import java.net.DatagramPacket;
import java.net.InetAddress;
import javax.lang.model.util.ElementScanner14;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;
import java.net.MulticastSocket;
import java.util.Scanner;


public class MulticastSuperClient{ 

    static Scanner scanner = new Scanner(System.in);
    static String ip_Address3 ="226.12.8.13";
    static int port_C = 9200;


    public static void main(String[] args) {
        String message = scanner.nextLine();
        System.out.println("Your sent: " + message);


        try {
            
            InetAddress group = InetAddress.getByName(ip_Address3);
            try (MulticastSocket socket = new MulticastSocket(port_C)) {
                byte[] buffer_1 = message.getBytes();
                DatagramPacket packet = new DatagramPacket(buffer_1, buffer_1.length, group, port_C);
                socket.send(packet);
            }
        } catch (IOException se) {
            se.printStackTrace();
        }

    }
}