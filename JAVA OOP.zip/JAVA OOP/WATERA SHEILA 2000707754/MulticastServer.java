import java.io.*;
//import java.io.IOException;
import java.net.*;
import javax.lang.model.util.ElementScanner14;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;
//import java.net.InetAddress;   
//import java.net.MulticastSocket;
import java.util.concurrent.*;

public class MulticastServer {
    //declaration of messages to be sent to the client
    static String mssg1 = "This is my Packets message is for  Group NAD";
    static String mssg2 = "This is my Packets message is for Group OOP";
    //initialization of important variables to be used
    static String ip_Address1="225.13.8.19";
    static int port_A = 6000;

    static String ip_Address2 = "231.15.8.3";
    static int port_B = 6100;

    static String ip_Address3 = "226.12.8.13";
    static int port_C = 6200;


    // recieve message method
    public static void recieveMessage(String ip_Address3, int port_C) {

         // this sets  IPv4 as default

        System.setProperty("java.net.preferIPv4Stack", "true");
        
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(3);


        try {
            InetAddress group = InetAddress.getByName(ip_Address3);
            try (MulticastSocket socket = new MulticastSocket(port_C)) {
                socket.joinGroup(group);
                byte[] buffer_1= new byte[1024];
                DatagramPacket packet = new DatagramPacket(buffer_1, buffer_1.length);
                socket.receive(packet);

                System.out.println("This message was from the super client: " + new String(packet.getData()));


                scheduler.scheduleAtFixedRate(new Runnable() {
                    @Override

                    public void run() {
                        sendMessage(new String(packet.getData()), ip_Address1, port_A);
                    }
                }
                , 0, 5, TimeUnit.SECONDS);

                
                scheduler.scheduleAtFixedRate(new Runnable() {
                    @Override

                    public void run() {
                        sendMessage(new String(packet.getData()), ip_Address2, port_B);
                    }
                }
                , 0, 10, TimeUnit.SECONDS);
            }
        } catch (IOException se) {
            se.printStackTrace();
        }
    }

    // here, the multicast server and sends messages to clients
    public static void sendMessage(String message, String ip_Address1, int port) {
            try {
                InetAddress group = InetAddress.getByName(ip_Address1);
                try (MulticastSocket socket = new MulticastSocket(port)) {
                    byte[] buffer_1= message.getBytes();
                    DatagramPacket packet = new DatagramPacket(buffer_1, buffer_1.length, group, port);
                    socket.send(packet);
                }
            } 
            catch (IOException se) {
                se.printStackTrace();
            }
        }


    public static void main(String[] args) 
    { 
       recieveMessage(ip_Address3, port_C);
    }           
}
