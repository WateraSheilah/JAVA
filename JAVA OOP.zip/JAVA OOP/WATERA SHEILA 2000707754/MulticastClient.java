import java.io.*;
import java.net.*;
import javax.lang.model.util.ElementScanner14;
import javax.swing.plaf.basic.BasicOptionPaneUI.ButtonActionListener;
import java.util.*;

public class MulticastClient{
    public static int option;
    static Scanner scan = new Scanner(System.in);
    static String ip_Address1 ="225.13.8.19";
    static int port_A = 6000;

    static String ip_Address2 = "231.15.8.3";
    static int port_B = 6100;
    
    // multicast client recieves messages from server
    public static void recieveMessage(String ip_Address1, int port_A) {
        while (true) {
            try {
                
                InetAddress group = InetAddress.getByName(ip_Address1);
                try (MulticastSocket socket = new MulticastSocket(port)) {
                    socket.joinGroup(group);
                    byte[] buffer_1 =new byte[1024];
                    DatagramPacket packet = new DatagramPacket(buffer_1, buffer_1.length);
                    socket.receive(packet);
                    System.out.println("Received message: " + new String(packet.getData()));
                }

            } catch (IOException se) {
                se.printStackTrace();
            }
        }
    }
    public static void main(String[] args){

        // join  a multicast group and send messages
        do {
            System.out.println("Please select the group you want to belong to .");
            

            System.out.println("1..... Group NAD");
            System.out.println("2..... Group OOP");
            

            System.out.println("Option: ");
            option= scan.nextInt();

        } while (option!= 1 && option!= 2);

        //recieve message method
       
        switch(option){
            case 1:
               recieveMessage(ip_Address1, port_A);
                break;
            case 2:
                recieveMessage(ip_Address2, port_B);
                break;

            }
        }
       
}
