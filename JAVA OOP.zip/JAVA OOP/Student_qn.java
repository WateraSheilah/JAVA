import java.io.*;
import java.util.*;
import java.net.*;
//import java.lang.*;
public class Student_qn {
    String name;
    String id;
    int age;
    public Student_qn(String n, String i){
        name=n;
        id=i;
        //this.age=a;
    }
    public static void main(String[]args){
        Student_qn s=new Student_qn ("Watera","20/PS");
        Scanner c =new Scanner(System.in);
        System.out.println("Enter your age");
        s.age=c.nextInt();
        
        System.out.println("Name: "+s.name);
        System.out.println("ID: "+s.id); 
        System.out.println("Age: "+s.age);

    }
}