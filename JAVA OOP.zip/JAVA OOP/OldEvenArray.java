import java.io.*;
import java.net.*;
//import java.util.*;
public class OldEvenArray {
    public static void main(String[] args){
        int[] even= new int[50];
        int[] old = new int[50];
        int e=0;
        int o=0;
        // to identify old and even numbers and store them in an array
        for(int i=0;i<100;i++){
            if(i%2==0){
             even[e]=i;
             e++;
//for even numbers
            }
            else if(i%2!=0){
            old[o]=i;
            o++;
            }
            //for old numbers
        }
        //to print the even numbers
        System.out.println("these are the even numbers: ");
        for(int j=0;j<even.length;j++){
            System.out.println(even[j]+" ");
        }
        System.out.println("the even length is: "+ even.length);
        //to print the old numbers
        System.out.println("these are the old numbers: ");
        for(int j=0;j<old.length;j++){
            System.out.println(old[j]+"");
    }
    System.out.println("the odd length is: "+ old.length);
}
    
}
