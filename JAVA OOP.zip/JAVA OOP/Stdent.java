public class Stdent {
    String name;
    
    
}
